<?php echo e($slot); ?>

<?php /**PATH D:\tugas\SEMESTER_5\PRAKTIKUM_PROGMOB\RestApi\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>