<?php $__env->startSection('tittle','home'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="card">
                <h5 class="card-header">Tambah Produk</h5>
                <div class="card-body">
                    <form action="/produk/<?php echo e($produk->id); ?>" method="POST" class="form-group">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("PUT"); ?>
                            <div class="form-header">
                                <h3>Form Edit Produk</h3>
                            </div>
                            
                            <div class="form-body">
                                    <div class="form-label">
                                        <label for="nim">Produk</label>
                                    </div>
                                <input type="text" class="form-control" name="nama_produk" value="<?php echo e($produk->nama_produk); ?>" />
                                    <br>
                                <div class="form-label">
                                    <label for="nim">Harga</label>
                                </div>
                            <input type="text" class="form-control" name="harga" value="<?php echo e($produk->harga); ?>" />
                                <br>

                                <select name="id_kategori" class="form-control">
                                    <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($k->id); ?>" <?php if($produk->id_kategori == $k->id): ?>
                                            selected="selected"
                                        <?php endif; ?>><?php echo e($k->kategori); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            
                            <br>
                            <div class="form-footer">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>

                    </div>
                
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\tugas\SEMESTER_5\PRAKTIKUM_PROGMOB\RestApi\resources\views/produk/edit.blade.php ENDPATH**/ ?>