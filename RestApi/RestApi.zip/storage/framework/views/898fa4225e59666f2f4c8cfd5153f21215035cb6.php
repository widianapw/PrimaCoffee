<?php $__env->startSection('tittle','home'); ?>
<?php $__env->startSection('content'); ?>
<form action="/kategori/<?php echo e($kategori->id); ?>" method="POST" class="form-group">
        <?php echo csrf_field(); ?>
        <?php echo method_field("PUT"); ?>
        <div class="form-header">
            <h3>Form Edit Kategori</h3>
        </div>
        
        <div class="form-body">
                <div class="form-label">
                    <label for="nim">Kategori</label>
                </div>
            <input type="text" class="form-control" name="kategori" value="<?php echo e($kategori->kategori); ?>" />
            
        <br>
        <div class="form-footer">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\tugas\SEMESTER_5\PRAKTIKUM_PROGMOB\RestApi\resources\views/kategori/edit.blade.php ENDPATH**/ ?>