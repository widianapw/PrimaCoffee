<?php $__env->startSection('title','Tambah Produk'); ?>
<?php $__env->startSection('judul','Tambah Produk'); ?>
<?php $__env->startSection('content'); ?>

<form action="/produk" method="POST" class="form-group">
    <?php echo csrf_field(); ?>
    <div class="form-body">

        <div class="form-label">
            <label for="nim">Nama Produk</label>
        </div>
        <input type="text" class="form-control" name="nama_produk" required/>
        <br>
        <div class="form-label">
            <label for="nim">Harga</label>
        </div>
        <input type="number" class="form-control" name="harga" required/>
        <br>
        <div class="form-label">
            <label for="nim">Kategori</label>
        </div>
        <select name="kategori" class="form-control" required>
            <option value="">Pilih Kategori</option>
            <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($k->id); ?>"><?php echo e($k->kategori); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <br>
        
        

        <br>
        <div class="form-footer">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\tugas\SEMESTER_5\PRAKTIKUM_PROGMOB\RestApi\resources\views/produk/create.blade.php ENDPATH**/ ?>