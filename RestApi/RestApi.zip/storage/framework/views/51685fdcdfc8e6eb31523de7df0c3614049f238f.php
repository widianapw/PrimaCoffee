<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\tugas\SEMESTER_5\PRAKTIKUM_PROGMOB\RestApi\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>