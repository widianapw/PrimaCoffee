<?php $__env->startSection('title','Data Kategori'); ?>
<?php $__env->startSection('judul','Data Kategori'); ?>
<?php $__env->startSection('content'); ?>
<form action="/kategori/create/" method="GET" class="button">
    <button type="submit" class="btn btn-primary">
        Tambah Data
    </button>
</form>
<div class="table-responsive">
    <table class="table table-striped ">
        <thead>
            <tr>
                <th>No.</th>
                <th>Kategori</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($m->kategori); ?></td>
                <td>
                    <form action="/kategori/<?php echo e($m->id); ?>/edit" method="GET">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-warning">
                            <i class="fa fa-fw fa-edit" style="color:white"></i>
                        </button>
                    </form>
                </td>
                <td>
                    <form action="/kategori/<?php echo e($m->id); ?>/" method="POST">
                        <?php echo method_field("DELETE"); ?>
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger">
                            <i class="fa fa-fw fa-trash"></i>
                        </button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\tugas\SEMESTER_5\PRAKTIKUM_PROGMOB\RestApi\resources\views/kategori/index.blade.php ENDPATH**/ ?>