<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('judul','Dashboard'); ?>
<?php $__env->startSection('content'); ?>

<div class="">
    <div class="card">
        <h5 class="card-header">Total Pendapatan</h5>
        <div class="card-body">
            <div>
                <canvas id="canvas"></canvas>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <h5 class="card-header">Produk Terlaris</h5>
    <div class="card-body">
        <table class="table table-hover">
            <thead>
                <th>
                    No
                </th>
                <th>
                    Nama Produk
                </th>
                <th>
                    Total Dibeli
                </th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($p->nama_produk); ?></td>
                    <td><?php echo e($p->total); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\tugas\SEMESTER_5\PRAKTIKUM_PROGMOB\RestApi\resources\views/dashboard.blade.php ENDPATH**/ ?>